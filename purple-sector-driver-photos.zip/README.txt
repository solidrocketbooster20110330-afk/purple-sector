Purple Sector — driver portrait images

Images are original WebP files, preserved without re-encoding.
Suggested destination in the repository: public/images/drivers/
There are 24 portraits in this archive, although 22 were initially expected.
Files are grouped by visible team uniform and numbered because no individual-name labels were provided.
Liam Lawson / RB preference was noted separately; confirm the exact portrait before assigning an individual filename.

Files:
public/images/drivers/mclaren-01.webp
public/images/drivers/mclaren-02.webp
public/images/drivers/mercedes-01.webp
public/images/drivers/mercedes-02.webp
public/images/drivers/red-bull-01.webp
public/images/drivers/red-bull-02.webp
public/images/drivers/red-bull-03.webp
public/images/drivers/ferrari-01.webp
public/images/drivers/ferrari-02.webp
public/images/drivers/williams-01.webp
public/images/drivers/williams-02.webp
public/images/drivers/racing-bulls-01.webp
public/images/drivers/racing-bulls-02.webp
public/images/drivers/racing-bulls-03.webp
public/images/drivers/aston-martin-01.webp
public/images/drivers/aston-martin-02.webp
public/images/drivers/haas-01.webp
public/images/drivers/haas-02.webp
public/images/drivers/audi-01.webp
public/images/drivers/audi-02.webp
public/images/drivers/alpine-01.webp
public/images/drivers/alpine-02.webp
public/images/drivers/cadillac-01.webp
public/images/drivers/cadillac-02.webp
